  
let myImg;
let myFont;
let result;

function setup() {
  createCanvas(1920, 1080);
   
}
function preload(){
  myImg = loadImage('solar system.jpg'); //loading Image
  result = loadStrings('BroadwayRegular-7Bpow.ttf');
  
}

function draw() {
  image(myImg, 0,0); //drawing image
  tint(0,153,204);//creating blue tint
  image(myImg,50,0)
    
}
function mousePressed(){
  myImg.resize(960,540); //creating a image half its original size                            //when mouse presssed
}